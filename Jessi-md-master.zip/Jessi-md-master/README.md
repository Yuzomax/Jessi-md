 
<img src="https://telegra.ph/file/3eb2954a6daa8d9f4fbb8.jpg" alt="jessimd" width="1280"/>
</p>

### MS.JESSICA MULTI DEVICE


- ✔️ | **Simple**
- ✔️ | **No Button**
- ✔️ | **Multi Device**
- ✔️ | **Plugins**
  

---------
> I opened discussiond for asking any problem or new feature, if i agree with that i will invite you in my repo/pull request your idea in this source code :) [Whatsapp Group](https://chat.whatsapp.com/I1uZccqxoqx5sOPrYHsbyc)


![forks](https://img.shields.io/github/forks/whiteshadowofficial/Jessi-md?label=Forks&style=social)  ![stars](https://img.shields.io/github/stars/whiteshadowofficial/Jessi-md?style=social)

<br>


### ⏱️ Installation

 <a href='https://jessipair-75e8bcfb723f.herokuapp.com/' target="_blank"><img alt='Install bot' src='https://img.shields.io/badge/Install Bot-000?style=for-the-badge&logo=vercal&logoColor=white'/></a>

Upload creds.json to > sessions folder in your forked repository 
---

### Deploy to heroku

 Fork the repo
 
 <a href='https://github.com/whiteshadowofficial/Jessi-md/fork' target="_blank"><img alt='Fork repo' src='https://img.shields.io/badge/fork repo-000?style=for-the-badge&logo=github&logoColor=white'/></a>
 
 <a href='Heroku.com/deploy?template=https://github.com/whiteshadowofficial/Jessi-md' target="_blank"><img alt='Deploy Heroku' src='https://img.shields.io/badge/deploy heroku-000?style=for-the-badge&logo=heroku&logoColor=white'/></a>
 

### Deploy to Replit

 <a href='https://replit.com/github/whiteshadowofficial/Jessi-md' target="_blank"><img alt='Run Replit' src='https://img.shields.io/badge/Run Replit-000?style=for-the-badge&logo=Replit&logoColor=white'/></a>

---------

## FOR WINDOWS/VPS/RDP USER

* Download And Install Git [`Click Here`](https://git-scm.com/downloads)
* Download And Install NodeJS [`Click Here`](https://nodejs.org/en/download)
* Download And Install FFmpeg [`Click Here`](https://ffmpeg.org/download.html) (**Don't Forget Add FFmpeg to PATH enviroment variables**)
* Download And Install ImageMagick [`Click Here`](https://imagemagick.org/script/download.php)

```bash
git clone https://github.com/whiteshadowofficial/Jessi-md
cd jessi-md
npm install
```

---------

  
 ```bash
 𝐀𝐮𝐭𝐡𝐨𝐫 : White Shadow ofc
 𝐖𝐚 : +94779529221
 𝐌𝐲 𝐏𝐫𝐨𝐣𝐞𝐜𝐭 : 6 may 2020
 ```


---------

### 📮 S&K
1. Not For Sale
2. Don't forget give star this repo
3. Follow Github
4. Don't use this repository wrong!
5. If you have problem chat me in owner number

---------


## ```Thanks to ✨```
* [`Me`]
* [`My parents`]
* [`All Friends`]
* [`All Contributors`]
* [`All Creator Bot`]
* [`@adiwajshing/baileys`](https://github.com/adiwajshing/baileys)
* [`Whiskeysockets/Baileys`](https://github.com/WhiskeySockets/Baileys)
* [`Nurutomo`](https://github.com/Nurutomo)
* [`Mr.White Shadow`](https://github.com/whiteshadowofficial)

## 👨‍💻 Developers & Contributors 👨‍💻

## Developers
  <div align="center">
    
  [![MrChaby](https://github.com/MrChaby.png?size=100)](https://github.com/MrChaby) |  [![Mr.White Shadow](https://github.com/whiteshadowofficial.png?size=100)](https://github.com/whiteshadowofficial) | [![Diegoson](https://github.com/D3centX.png?size=100)](https://github.com/D3centX) 
----|----|----
[MrChaby](https://github.com/MrChaby)  | [Mr.White Shadow](https://github.com/whiteshadowofficial) | [Diegoson](https://github.com/D3centX)
Bug Fixes, Modules | Code Owner,Base | Bug Fixes, Modules

[![Tutux](https://github.com/Tutux1.png?size=100)](https://github.com/Tutux1) |  [![Black Panther Shadow](https://github.com/blackpantherofc.png?size=100)](https://github.com/blackpantherofc) | [![Hisham-Muhammed](https://github.com/Hisham-Muhammed.png?size=100)](https://github.com/Hisham-Muhammed) 
----|----|----
[Tutux](https://github.com/Tutux1)  | [Black Panther](https://github.com/blackpantherofc) | [Hisham-Muhammed](https://github.com/Hisham-Muhammed)
Modifiying  as   public | Modifiying  as   public | Help To Me



## ⚠ Warning ⚠

```
By using kick, add, promote, demote Commands, Your WhatsApp account may be banned.Jessi or we are not responsible for your account,This bot is intended for the purpose of having fun with some fun commands and group management with some helpfull commands.

If  you ended up spamming groups, getting reported left and right, 
and you ended up in being fight with WhatsApp
and at the end WhatsApp Team deleted your account. DON'T BLAME US.

No personal support will be provided / We won't spoon feed you. 
If you need help ask in our support group 
and we will try to help you.
```
  

> License: [MIT](https://github.com/whiteshadowofficial/LICENSE)

> Click WA logo to Join Support Group 👇
<br>

  [![join](https://github.com/Alien-alfa/PublicBot/blob/main/wlogo.svg.png)](https://chat.whatsapp.com/I1uZccqxoqx5sOPrYHsbyc)

  <div align="center">


> ### Disclaimer
----

>`WhatsApp` name, its variations and the logo are registered trademarks of Facebook. We have nothing to do with the registered trademark
.

> The project was created by Mr.White Shadow

____________________________________________

> *||Copyright © 2021 All right reserved||*

____________________________________________
